using Legacy.Maliev.CareerService.Application.Interfaces;
using Legacy.Maliev.CareerService.Application.Models;
using Legacy.Maliev.CareerService.Domain;

namespace Legacy.Maliev.CareerService.Application.Services;

/// <summary>Implements legacy-compatible career behavior.</summary>
public sealed class CareerApplicationService(ICareerRepository repository, TimeProvider timeProvider) : ICareerService
{
    /// <inheritdoc />
    public async Task<PaginatedJobOfferResponse> GetPaginatedAsync(JobSortType? sort, string? search, int? index, int? size, CancellationToken cancellationToken)
    {
        return await repository.GetPaginatedOffersAsync(sort, search, index, size, cancellationToken);
    }

    /// <inheritdoc />
    public Task<bool> HasOpenPositionsAsync(CancellationToken cancellationToken) => repository.HasOpenPositionsAsync(cancellationToken);

    /// <inheritdoc />
    public async Task<JobOfferResponse?> GetOfferByIdAsync(int id, CancellationToken cancellationToken) =>
        (await repository.GetOfferByIdAsync(id, cancellationToken)) is { } offer ? ToResponse(offer) : null;

    /// <inheritdoc />
    public async Task<JobOfferResponse> CreateOfferAsync(UpsertJobOfferRequest request, CancellationToken cancellationToken)
    {
        var now = UtcWallClockNow();
        var offer = new JobOffer
        {
            LevelId = request.LevelId,
            Title = request.Title,
            Description = request.Description,
            Prerequisites = request.Prerequisites,
            IsFilled = request.IsFilled,
            CreatedDate = now,
            ModifiedDate = now,
        };
        await repository.AddOfferAsync(offer, cancellationToken);
        return ToResponse(offer);
    }

    /// <inheritdoc />
    public async Task<bool> UpdateOfferAsync(int id, UpsertJobOfferRequest request, CancellationToken cancellationToken)
    {
        var offer = await repository.GetOfferByIdForUpdateAsync(id, cancellationToken);
        if (offer is null)
        {
            return false;
        }

        offer.LevelId = request.LevelId;
        offer.Title = request.Title;
        offer.Description = request.Description;
        offer.Prerequisites = request.Prerequisites;
        offer.IsFilled = request.IsFilled;
        offer.ModifiedDate = UtcWallClockNow();
        await repository.UpdateOfferAsync(offer, cancellationToken);
        return true;
    }

    /// <inheritdoc />
    public async Task<bool> DeleteOfferAsync(int id, CancellationToken cancellationToken)
    {
        var offer = await repository.GetOfferByIdForUpdateAsync(id, cancellationToken);
        if (offer is null)
        {
            return false;
        }

        await repository.DeleteOfferAsync(offer, cancellationToken);
        return true;
    }

    /// <inheritdoc />
    public async Task<IReadOnlyList<JobLevelResponse>> GetLevelsAsync(CancellationToken cancellationToken) =>
        (await repository.GetLevelsAsync(cancellationToken)).Select(ToResponse).ToArray();

    /// <inheritdoc />
    public async Task<JobLevelResponse?> GetLevelByIdAsync(int id, CancellationToken cancellationToken) =>
        (await repository.GetLevelByIdAsync(id, cancellationToken)) is { } level ? ToResponse(level) : null;

    /// <inheritdoc />
    public async Task<JobLevelResponse> CreateLevelAsync(UpsertJobLevelRequest request, CancellationToken cancellationToken)
    {
        var now = UtcWallClockNow();
        var level = new JobLevel { Name = request.Name, Description = request.Description, CreatedDate = now, ModifiedDate = now };
        await repository.AddLevelAsync(level, cancellationToken);
        return ToResponse(level);
    }

    /// <inheritdoc />
    public async Task<bool> UpdateLevelAsync(int id, UpsertJobLevelRequest request, CancellationToken cancellationToken)
    {
        var level = await repository.GetLevelByIdForUpdateAsync(id, cancellationToken);
        if (level is null)
        {
            return false;
        }

        level.Name = request.Name;
        level.Description = request.Description;
        level.ModifiedDate = UtcWallClockNow();
        await repository.UpdateLevelAsync(level, cancellationToken);
        return true;
    }

    /// <inheritdoc />
    public async Task<bool> DeleteLevelAsync(int id, CancellationToken cancellationToken)
    {
        var level = await repository.GetLevelByIdForUpdateAsync(id, cancellationToken);
        if (level is null)
        {
            return false;
        }

        await repository.DeleteLevelAsync(level, cancellationToken);
        return true;
    }

    private static JobOfferResponse ToResponse(JobOffer offer) => new(
        offer.Id,
        offer.LevelId,
        offer.Title,
        offer.Introduction,
        offer.Description,
        offer.Prerequisites,
        offer.WhatWeOffer,
        offer.Location,
        offer.IsFilled,
        offer.CreatedDate,
        offer.ModifiedDate,
        offer.Level is null ? null : ToResponse(offer.Level, includeOffers: false));

    private static JobLevelResponse ToResponse(JobLevel level) => ToResponse(level, includeOffers: true);

    private static JobLevelResponse ToResponse(JobLevel level, bool includeOffers) => new(
        level.Id,
        level.Name,
        level.Description,
        level.CreatedDate,
        level.ModifiedDate)
    {
        // Original standalone level queries do not load linked offers. The job-list
        // producer explicitly nulls this collection before serializing its projection.
        Offers = includeOffers ? [] : null
    };

    private DateTime UtcWallClockNow() =>
        DateTime.SpecifyKind(timeProvider.GetUtcNow().UtcDateTime, DateTimeKind.Unspecified);
}
