using System.Net;
using System.Net.Http.Json;
using System.Text;
using Legacy.Maliev.CareerService.Domain;
using Microsoft.EntityFrameworkCore;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerOriginalMutationParityHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Fact]
    public async Task OfferCreate_PersistsAllOriginalFieldsAndOverridesCallerCreatedDate()
    {
        await fixture.ResetAsync();
        var levelId = await fixture.SeedLevelAsync();
        var suppliedCreatedDate = new DateTime(2000, 5, 6);
        using var client = fixture.Client("legacy-career.jobs.create");
        using var response = await client.PostAsJsonAsync("/Jobs", new
        {
            CreatedDate = suppliedCreatedDate,
            Description = "Test description",
            IsFilled = true,
            LevelId = levelId,
            Title = "Test title",
            Prerequisites = "Test prerequisites"
        });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        await using var db = fixture.Context();
        var stored = await db.Offers.AsNoTracking().SingleAsync();
        Assert.NotEqual(suppliedCreatedDate, stored.CreatedDate);
        Assert.Equal("Test description", stored.Description);
        Assert.Equal((bool?)true, stored.IsFilled);
        Assert.Equal(levelId, stored.LevelId);
        Assert.Equal("Test title", stored.Title);
        Assert.Equal("Test prerequisites", stored.Prerequisites);
    }

    [Fact]
    public async Task LevelCreate_PersistsBothOriginalFieldsAndOverridesCallerCreatedDate()
    {
        await fixture.ResetAsync();
        var suppliedCreatedDate = new DateTime(2000, 5, 6);
        using var client = fixture.Client("legacy-career.levels.create");
        using var response = await client.PostAsJsonAsync("/jobs/levels", new
        {
            CreatedDate = suppliedCreatedDate,
            Description = "Test description",
            Name = "Test name"
        });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        await using var db = fixture.Context();
        var stored = await db.Levels.AsNoTracking().SingleAsync();
        Assert.NotEqual(suppliedCreatedDate, stored.CreatedDate);
        Assert.Equal("Test description", stored.Description);
        Assert.Equal("Test name", stored.Name);
    }

    [Fact]
    public async Task LevelUpdate_PreservesCreatedDateAndPersistsDescriptionNameAndModifiedDate()
    {
        await fixture.ResetAsync();
        var seed = new JobLevel
        {
            CreatedDate = new DateTime(2000, 5, 6),
            Description = "Test description",
            Name = "Test name"
        };
        await using (var db = fixture.Context())
        {
            db.Levels.Add(seed);
            await db.SaveChangesAsync();
        }
        using var client = fixture.Client("legacy-career.levels.update");
        using var response = await client.PutAsJsonAsync($"/jobs/levels/{seed.Id}", new
        {
            Description = "new description",
            Name = "new name"
        });
        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
        await using var readback = fixture.Context();
        var stored = await readback.Levels.AsNoTracking().SingleAsync();
        Assert.Equal(seed.CreatedDate, stored.CreatedDate);
        Assert.NotNull(stored.ModifiedDate);
        Assert.Equal("new description", stored.Description);
        Assert.Equal("new name", stored.Name);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task LevelNullUpdateBody_IsBadRequestBeforeExistingOrMissingLookup(bool missing)
    {
        await fixture.ResetAsync();
        var id = missing ? int.MaxValue : await fixture.SeedLevelAsync();
        await using var db = fixture.Context();
        var before = await db.Levels.AsNoTracking().OrderBy(level => level.Id)
            .Select(level => new { level.Id, level.Name, level.Description, level.CreatedDate, level.ModifiedDate,
                Version = EF.Property<uint>(level, "Version") }).ToArrayAsync();
        using var client = fixture.Client("legacy-career.levels.update");
        using var body = new StringContent("null", Encoding.UTF8, "application/json");
        using var response = await client.PutAsync($"/jobs/levels/{id}", body);
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        var after = await db.Levels.AsNoTracking().OrderBy(level => level.Id)
            .Select(level => new { level.Id, level.Name, level.Description, level.CreatedDate, level.ModifiedDate,
                Version = EF.Property<uint>(level, "Version") }).ToArrayAsync();
        Assert.Equal(before, after);
        Assert.False(await db.Offers.AnyAsync());
    }

    [Theory]
    [InlineData("Jobs", "legacy-career.jobs.update")]
    [InlineData("jobs/levels", "legacy-career.levels.update")]
    public async Task EmptyUpdateObject_MissingIntMaxReturns404WithoutPersistence(string route, string permission)
    {
        await fixture.ResetAsync();
        using var client = fixture.Client(permission);
        using var body = new StringContent("{}", Encoding.UTF8, "application/json");
        using var response = await client.PutAsync($"/{route}/{int.MaxValue}", body);
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        await using var db = fixture.Context();
        Assert.False(await db.Offers.AnyAsync());
        Assert.False(await db.Levels.AnyAsync());
    }
}
