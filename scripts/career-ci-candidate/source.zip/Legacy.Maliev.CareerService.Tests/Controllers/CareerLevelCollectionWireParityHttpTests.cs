using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.CareerService.Domain;
using Microsoft.EntityFrameworkCore;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerLevelCollectionWireParityHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task StandaloneLevel_EmitsEmptyOffersEvenWhenLinked_JobProjectionOmitsOffers(bool linked)
    {
        await fixture.ResetAsync();
        int levelId;
        await using (var db = fixture.Context())
        {
            var level = new JobLevel { Name = "Synthetic level" };
            db.Levels.Add(level);
            await db.SaveChangesAsync();
            levelId = level.Id;
            if (linked)
            {
                db.Offers.AddRange(
                    new JobOffer { LevelId = levelId, Title = "First", IsFilled = false },
                    new JobOffer { LevelId = levelId, Title = "Second", IsFilled = true });
                await db.SaveChangesAsync();
            }
        }

        using var reader = fixture.Client();
        // Exercise job projection first; a later request must not inherit its omission.
        using (var jobs = await reader.GetAsync("/Jobs"))
        {
            Assert.Equal(linked ? HttpStatusCode.OK : HttpStatusCode.NotFound, jobs.StatusCode);
            if (linked)
            {
                using var document = JsonDocument.Parse(await jobs.Content.ReadAsStringAsync());
                var items = document.RootElement.GetProperty("items").EnumerateArray().ToArray();
                Assert.Equal(2, items.Length);
                foreach (var item in items)
                {
                    var level = item.GetProperty("level");
                    Assert.Equal(levelId, level.GetProperty("id").GetInt32());
                    Assert.False(level.TryGetProperty("offers", out _));
                    using var detail = await reader.GetAsync($"/Jobs/{item.GetProperty("id").GetInt32()}");
                    Assert.Equal(HttpStatusCode.OK, detail.StatusCode);
                    using var detailDocument = JsonDocument.Parse(await detail.Content.ReadAsStringAsync());
                    Assert.False(detailDocument.RootElement.GetProperty("level").TryGetProperty("offers", out _));
                }
            }
        }

        foreach (var route in new[] { "/jobs/levels", $"/jobs/levels/{levelId}" })
        {
            using var response = await reader.GetAsync(route);
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var level = document.RootElement.ValueKind == JsonValueKind.Array
                ? Assert.Single(document.RootElement.EnumerateArray().ToArray()) : document.RootElement;
            Assert.Equal(levelId, level.GetProperty("id").GetInt32());
            Assert.Equal(new[] { "id", "name", "offers" }, level.EnumerateObject().Select(property => property.Name).Order(StringComparer.Ordinal).ToArray());
            Assert.Equal(JsonValueKind.Array, level.GetProperty("offers").ValueKind);
            Assert.Equal(0, level.GetProperty("offers").GetArrayLength());
        }

        await using var readback = fixture.Context();
        Assert.Equal(1, await readback.Levels.CountAsync());
        Assert.Equal(linked ? 2 : 0, await readback.Offers.CountAsync());
        Assert.True(await readback.Offers.AllAsync(offer => offer.LevelId == levelId));
    }

    [Fact]
    public async Task CreateLevel_EmitsEmptyOffersAndLocationReadRetainsCollectionWithoutPersistingClientGraph()
    {
        await fixture.ResetAsync();
        using var writer = fixture.Client("legacy-career.levels.create");
        using var response = await writer.PostAsJsonAsync("/jobs/levels", new
        {
            name = "Created level",
            description = "Synthetic description",
            offers = new[] { new { id = 123456, title = "Client graph must not persist" } }
        });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.NotNull(response.Headers.Location);
        using var created = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var id = created.RootElement.GetProperty("id").GetInt32();
        Assert.Equal(0, created.RootElement.GetProperty("offers").GetArrayLength());
        Assert.False(created.RootElement.TryGetProperty("Offers", out _));
        using var reader = fixture.Client();
        using var detail = await reader.GetAsync(response.Headers.Location);
        Assert.Equal(HttpStatusCode.OK, detail.StatusCode);
        using var read = JsonDocument.Parse(await detail.Content.ReadAsStringAsync());
        Assert.Equal(id, read.RootElement.GetProperty("id").GetInt32());
        Assert.Equal(0, read.RootElement.GetProperty("offers").GetArrayLength());
        await using var db = fixture.Context();
        Assert.Equal("Created level", (await db.Levels.SingleAsync()).Name);
        Assert.Equal(0, await db.Offers.CountAsync());
    }
}
