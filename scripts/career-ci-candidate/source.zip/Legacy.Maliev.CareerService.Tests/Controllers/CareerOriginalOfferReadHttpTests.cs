using System.Net;
using System.Text.Json;
using Legacy.Maliev.CareerService.Domain;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerOriginalOfferReadHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Fact]
    public async Task OfferExist_ShouldReturnRequestedOfferId()
    {
        await fixture.ResetAsync();
        int offerId;
        await using (var db = fixture.Context())
        {
            var level = new JobLevel { Name = "Read principal", Description = "Read principal" };
            db.Levels.Add(level);
            await db.SaveChangesAsync();
            var offer = new JobOffer { LevelId = level.Id, Title = "Read offer" };
            db.Offers.Add(offer);
            await db.SaveChangesAsync();
            offerId = offer.Id;
        }
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/Jobs/{offerId}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal(offerId, json.RootElement.GetProperty("id").GetInt32());
    }

    [Fact]
    public async Task OfferNotExist_ShouldReturnNotFound()
    {
        await fixture.ResetAsync();
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/Jobs/{int.MaxValue}");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
