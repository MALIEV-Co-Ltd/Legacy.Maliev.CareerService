namespace Legacy.Maliev.CareerService.Tests.Controllers;

public sealed class CareerRouteFixtureLifetimeTests
{
    [Theory]
    [InlineData("postgres")]
    [InlineData("redis")]
    [InlineData("initialize")]
    public async Task StartupFailure_AlwaysDisposesBothExistingProvidersAndRetainsPrimaryFailure(string failureAt)
    {
        var events = new List<string>();
        var failure = new InvalidOperationException(failureAt);
        Task Step(string name, CancellationToken token)
        {
            Assert.True(token.CanBeCanceled);
            events.Add(name);
            return name == failureAt ? Task.FromException(failure) : Task.CompletedTask;
        }

        var actual = await Assert.ThrowsAsync<InvalidOperationException>(() => CareerRouteFixtureLifetime.InitializeAsync(
            token => Step("postgres", token), token => Step("redis", token), token => Step("initialize", token),
            () => { events.Add("dispose-redis"); return Task.CompletedTask; },
            () => { events.Add("dispose-postgres"); return Task.CompletedTask; }, TimeSpan.FromSeconds(1)));

        Assert.Same(failure, actual);
        Assert.Equal(new[] { "dispose-redis", "dispose-postgres" }, events.TakeLast(2));
        if (failureAt == "postgres") Assert.DoesNotContain("redis", events);
        if (failureAt != "initialize") Assert.DoesNotContain("initialize", events);
    }

    [Fact]
    public async Task SuccessfulInitialization_KeepsProvidersUntilNormalFixtureDisposal()
    {
        var disposed = 0;
        await CareerRouteFixtureLifetime.InitializeAsync(_ => Task.CompletedTask, _ => Task.CompletedTask,
            _ => Task.CompletedTask, () => { disposed++; return Task.CompletedTask; },
            () => { disposed++; return Task.CompletedTask; }, TimeSpan.FromSeconds(1));
        Assert.Equal(0, disposed);
    }

    [Fact]
    public async Task RedisStartupTimeout_DisposesBothProviders()
    {
        var events = new List<string>();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => CareerRouteFixtureLifetime.InitializeAsync(
            _ => Task.CompletedTask, token => Task.Delay(Timeout.InfiniteTimeSpan, token), _ => Task.CompletedTask,
            () => { events.Add("redis"); return Task.CompletedTask; },
            () => { events.Add("postgres"); return Task.CompletedTask; }, TimeSpan.FromMilliseconds(20)));
        Assert.Equal(new[] { "redis", "postgres" }, events);
    }

    [Fact]
    public async Task RedisDisposalFailure_StillDisposesPostgresAndRetainsBothFailures()
    {
        var primary = new InvalidOperationException("redis-start");
        var cleanup = new InvalidOperationException("redis-dispose");
        var postgresDisposed = false;
        var actual = await Assert.ThrowsAsync<AggregateException>(() => CareerRouteFixtureLifetime.InitializeAsync(
            _ => Task.CompletedTask, _ => Task.FromException(primary), _ => Task.CompletedTask,
            () => Task.FromException(cleanup), () => { postgresDisposed = true; return Task.CompletedTask; }, TimeSpan.FromSeconds(1)));
        Assert.True(postgresDisposed);
        Assert.Same(primary, actual.InnerExceptions[0]);
        Assert.Contains(cleanup, ((AggregateException)actual.InnerExceptions[1]).InnerExceptions);
    }

    [Fact]
    public async Task NoncooperativeLateStartup_SettlesBeforeProviderDisposal()
    {
        var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancelled = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var events = new List<string>();
        var evidence = new CareerRouteFixtureLifetime.StartupEvidence();
        Task? retained = null;
        async Task IgnoreCancellation(CancellationToken token)
        {
            using var registration = token.Register(() => cancelled.TrySetResult());
            await release.Task;
            events.Add("late-acquisition");
        }

        var initialization = CareerRouteFixtureLifetime.InitializeAsync(_ => Task.CompletedTask,
            token => retained = IgnoreCancellation(token), _ => Task.CompletedTask,
            () => { events.Add("dispose-redis"); return Task.CompletedTask; },
            () => { events.Add("dispose-postgres"); return Task.CompletedTask; },
            TimeSpan.FromMilliseconds(20), evidence, TimeSpan.FromSeconds(10));
        try
        {
            await cancelled.Task.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(initialization.IsCompleted);
            Assert.False(evidence.Settled);
            Assert.False(evidence.CleanupAttempted);
            Assert.True(evidence.Cancellation.IsCancellationRequested);
            Assert.Same(retained, evidence.Operation);
            release.SetResult();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => initialization);
            Assert.Equal(new[] { "late-acquisition", "dispose-redis", "dispose-postgres" }, events);
            Assert.True(evidence.Settled);
            Assert.True(evidence.CleanupCallsCompleted);
        }
        finally
        {
            release.TrySetResult();
            if (retained is not null) await retained;
            try { await initialization; }
            catch (Exception) { }
        }
    }

    [Fact]
    public async Task NoncooperativeUnsettledStartup_RetainsTaskAndRefusesCleanupClaim()
    {
        var late = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var evidence = new CareerRouteFixtureLifetime.StartupEvidence();
        var disposalCalls = 0;
        try
        {
            var actual = await Assert.ThrowsAsync<AggregateException>(() => CareerRouteFixtureLifetime.InitializeAsync(
                _ => Task.CompletedTask, _ => late.Task, _ => Task.CompletedTask,
                () => { disposalCalls++; return Task.CompletedTask; },
                () => { disposalCalls++; return Task.CompletedTask; },
                TimeSpan.FromMilliseconds(20), evidence, TimeSpan.FromMilliseconds(20)));
            Assert.Contains(actual.InnerExceptions, error => error is CareerRouteFixtureLifetime.StartupUnsettledException);
            Assert.Same(late.Task, evidence.Operation);
            Assert.Equal("redis", evidence.Phase);
            Assert.True(evidence.Cancellation.IsCancellationRequested);
            Assert.False(evidence.Settled);
            Assert.False(evidence.CleanupAttempted);
            Assert.False(evidence.CleanupCallsCompleted);
            Assert.Equal(0, disposalCalls);
        }
        finally
        {
            late.TrySetResult();
            await late.Task;
        }
    }

    [Fact]
    public async Task NoncooperativeRedisDisposal_RetainsOriginalTaskAndPrimaryWithoutBlindRetry()
    {
        var late = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var evidence = new CareerRouteFixtureLifetime.StartupEvidence();
        var primary = new InvalidOperationException("redis-start");
        var redisCalls = 0;
        var postgresCalls = 0;
        Task DisposeRedis() { redisCalls++; return late.Task; }
        Task DisposePostgres() { postgresCalls++; return Task.CompletedTask; }
        try
        {
            var actual = await Assert.ThrowsAsync<AggregateException>(() => CareerRouteFixtureLifetime.InitializeAsync(
                _ => Task.CompletedTask, _ => Task.FromException(primary), _ => Task.CompletedTask,
                DisposeRedis, DisposePostgres, TimeSpan.FromSeconds(1), evidence,
                disposalTimeout: TimeSpan.FromMilliseconds(20)));
            Assert.Same(primary, actual.InnerExceptions[0]);
            var unsettled = Assert.IsType<CareerRouteFixtureLifetime.DisposalUnsettledException>(
                Assert.Single(((AggregateException)actual.InnerExceptions[1]).InnerExceptions));
            Assert.Equal("redis", unsettled.Phase);
            Assert.Same(late.Task, unsettled.Operation);
            Assert.Same(evidence.Disposal, unsettled.Evidence);
            Assert.Same(late.Task, evidence.Disposal.Operations["redis"]);
            Assert.False(evidence.Disposal.Settled);
            Assert.False(evidence.CleanupCallsCompleted);
            Assert.False(evidence.Disposal.CleanupCallsCompleted);
            Assert.Equal(1, postgresCalls);
            await Assert.ThrowsAsync<AggregateException>(() => CareerRouteFixtureLifetime.DisposePairAsync(
                DisposeRedis, DisposePostgres, evidence.Disposal, TimeSpan.FromMilliseconds(20)));
            Assert.Equal(1, redisCalls);
            Assert.Equal(1, postgresCalls);
            late.SetResult();
            await evidence.Disposal.Operations["redis"].WaitAsync(TimeSpan.FromSeconds(5));
            await CareerRouteFixtureLifetime.DisposePairAsync(DisposeRedis, DisposePostgres, evidence.Disposal,
                TimeSpan.FromMilliseconds(20));
            Assert.True(evidence.Disposal.Settled);
            Assert.True(evidence.Disposal.CleanupCallsCompleted);
            Assert.Equal(1, redisCalls);
            Assert.Equal(1, postgresCalls);
        }
        finally
        {
            late.TrySetResult();
            await late.Task;
        }
    }

    [Fact]
    public async Task NoncooperativeFactoryDisposal_RetainsPhaseAndStillAttemptsBothProviders()
    {
        var late = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var evidence = new CareerRouteFixtureLifetime.DisposalEvidence();
        var factoryCalls = 0;
        var providers = new List<string>();
        Task DisposeFactory() { factoryCalls++; return late.Task; }
        try
        {
            var actual = await Assert.ThrowsAsync<CareerRouteFixtureLifetime.DisposalUnsettledException>(() =>
                CareerRouteFixtureLifetime.DisposeOneAsync("factory", DisposeFactory, evidence, TimeSpan.FromMilliseconds(20)));
            Assert.Equal("factory", actual.Phase);
            Assert.Same(late.Task, actual.Operation);
            Assert.Same(evidence, actual.Evidence);
            await CareerRouteFixtureLifetime.DisposePairAsync(
                () => { providers.Add("redis"); return Task.CompletedTask; },
                () => { providers.Add("postgres"); return Task.CompletedTask; }, evidence, TimeSpan.FromMilliseconds(20));
            Assert.Equal(new[] { "redis", "postgres" }, providers);
            Assert.Same(late.Task, evidence.Operations["factory"]);
            Assert.False(evidence.Settled);
            Assert.False(evidence.CleanupCallsCompleted);
            late.SetResult();
            await evidence.Operations["factory"].WaitAsync(TimeSpan.FromSeconds(5));
            await CareerRouteFixtureLifetime.DisposeOneAsync("factory", DisposeFactory, evidence, TimeSpan.FromMilliseconds(20));
            Assert.Equal(1, factoryCalls);
            Assert.True(evidence.Settled);
            Assert.True(evidence.CleanupCallsCompleted);
        }
        finally
        {
            late.TrySetResult();
            await late.Task;
        }
    }
}
