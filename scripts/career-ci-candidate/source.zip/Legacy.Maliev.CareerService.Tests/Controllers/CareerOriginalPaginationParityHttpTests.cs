using System.Net;
using System.Text.Json;
using Legacy.Maliev.CareerService.Domain;
using Microsoft.EntityFrameworkCore;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerOriginalPaginationParityHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Fact]
    public async Task ThousandOriginalOffers_PreserveDefaultCardinalityFirstLastFlagsAndTenPages()
    {
        await fixture.ResetAsync();
        await using (var db = fixture.Context())
        {
            db.Offers.AddRange(Enumerable.Range(0, 1000).Select(_ => new JobOffer
            {
                Level = new JobLevel { Description = "test description", Name = "test name" }
            }));
            await db.SaveChangesAsync();
        }
        using var client = fixture.Client();
        using (var response = await client.GetAsync("/Jobs"))
        {
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            Assert.Equal(1000, json.RootElement.GetProperty("totalRecords").GetInt32());
            Assert.False(json.RootElement.TryGetProperty("totalItems", out _));
            Assert.Equal(1000, json.RootElement.GetProperty("items").GetArrayLength());
            Assert.Equal(1, json.RootElement.GetProperty("pageIndex").GetInt32());
            Assert.Equal(1, json.RootElement.GetProperty("totalPages").GetInt32());
            Assert.False(json.RootElement.GetProperty("hasPreviousPage").GetBoolean());
            Assert.False(json.RootElement.GetProperty("hasNextPage").GetBoolean());
        }
        using (var response = await client.GetAsync("/Jobs?index=1&size=100"))
        {
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            Assert.False(json.RootElement.GetProperty("hasPreviousPage").GetBoolean());
            Assert.True(json.RootElement.GetProperty("hasNextPage").GetBoolean());
        }
        using (var response = await client.GetAsync("/Jobs?index=10&size=100"))
        {
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            Assert.True(json.RootElement.GetProperty("hasPreviousPage").GetBoolean());
            Assert.False(json.RootElement.GetProperty("hasNextPage").GetBoolean());
        }
        using (var response = await client.GetAsync("/Jobs?size=100"))
        {
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            Assert.Equal(10, json.RootElement.GetProperty("totalPages").GetInt32());
        }
        await using var readback = fixture.Context();
        Assert.Equal(1000, await readback.Offers.CountAsync());
        Assert.Equal(1000, await readback.Levels.CountAsync());
    }

    [Theory]
    [InlineData("JobCreatedDate_Ascending", 2000, 3000)]
    [InlineData("JobCreatedDate_Descending", 3000, 2000)]
    public async Task ThousandAndOneOriginalDates_PreserveYearEndpoints(string sort, int firstYear, int lastYear)
    {
        await fixture.ResetAsync();
        await using (var db = fixture.Context())
        {
            db.Offers.AddRange(Enumerable.Range(0, 1001).Select(i => new JobOffer
            {
                CreatedDate = new DateTime(2000 + i, 1, 1),
                Level = new JobLevel { Description = "test description", Name = "test name" }
            }));
            await db.SaveChangesAsync();
        }
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/Jobs?sort={sort}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var items = json.RootElement.GetProperty("items").EnumerateArray().ToArray();
        Assert.Equal(firstYear, items.First().GetProperty("createdDate").GetDateTime().Year);
        Assert.Equal(lastYear, items.Last().GetProperty("createdDate").GetDateTime().Year);
    }

    [Theory]
    [InlineData("JobId_Ascending", 1, 1000)]
    [InlineData("JobId_Descending", 1000, 1)]
    public async Task ThousandOriginalExplicitIds_PreserveIdEndpoints(string sort, int firstId, int lastId)
    {
        await fixture.ResetAsync();
        await using (var db = fixture.Context())
        {
            db.Offers.AddRange(Enumerable.Range(1, 1000).Select(id => new JobOffer
            {
                Id = id,
                Level = new JobLevel { Description = "test description", Name = "test name" }
            }));
            await db.SaveChangesAsync();
        }
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/Jobs?sort={sort}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var items = json.RootElement.GetProperty("items").EnumerateArray().ToArray();
        Assert.Equal(firstId, items.First().GetProperty("id").GetInt32());
        Assert.Equal(lastId, items.Last().GetProperty("id").GetInt32());
    }
}
