namespace Legacy.Maliev.CareerService.Tests.Controllers;

internal static class CareerRouteFixtureLifetime
{
    private static readonly TimeSpan CleanupTimeout = TimeSpan.FromSeconds(30);

    internal sealed class StartupEvidence
    {
        internal Task? Operation { get; private set; }
        internal string Phase { get; private set; } = "not-started";
        internal CancellationToken Cancellation { get; private set; }
        internal bool Settled => Operation?.IsCompleted != false;
        internal bool CleanupAttempted { get; set; }
        internal bool CleanupCallsCompleted { get; set; }
        internal DisposalEvidence Disposal { get; } = new();

        internal Task Retain(string phase, Task operation, CancellationToken cancellation)
        {
            Phase = phase;
            Operation = operation;
            Cancellation = cancellation;
            return operation;
        }
    }

    internal sealed class StartupUnsettledException(StartupEvidence evidence) : Exception("Provider startup remains live; cleanup is not verified.")
    {
        internal StartupEvidence Evidence { get; } = evidence;
    }

    internal sealed class DisposalEvidence
    {
        private readonly Dictionary<string, Task> operations = new();
        internal IReadOnlyDictionary<string, Task> Operations => operations;
        internal string Phase { get; private set; } = "not-started";
        internal bool Settled => operations.Values.All(operation => operation.IsCompleted);
        internal bool CleanupCallsCompleted { get; private set; }

        internal Task RetainOrReuse(string phase, Func<Task> dispose)
        {
            Phase = phase;
            CleanupCallsCompleted = false;
            if (operations.TryGetValue(phase, out var retained)) return retained;
            Task operation;
            try { operation = dispose(); }
            catch (Exception error) { operation = Task.FromException(error); }
            operations.Add(phase, operation);
            return operation;
        }

        internal void ObserveCompletion() => CleanupCallsCompleted = operations.Count > 0 &&
            operations.Values.All(operation => operation.IsCompletedSuccessfully);
    }

    internal sealed class DisposalUnsettledException(string phase, Task operation, DisposalEvidence evidence,
        Exception timeout) : Exception("Disposal remains live; cleanup is not verified.", timeout)
    {
        internal string Phase { get; } = phase;
        internal Task Operation { get; } = operation;
        internal DisposalEvidence Evidence { get; } = evidence;
    }

    internal static async Task InitializeAsync(Func<CancellationToken, Task> startPostgres,
        Func<CancellationToken, Task> startRedis, Func<CancellationToken, Task> initialize,
        Func<Task> disposeRedis, Func<Task> disposePostgres, TimeSpan startupTimeout,
        StartupEvidence? evidence = null, TimeSpan? settlementTimeout = null, TimeSpan? disposalTimeout = null)
    {
        using var startup = new CancellationTokenSource(startupTimeout);
        var settlementBudget = settlementTimeout ?? CleanupTimeout;
        if (settlementBudget <= TimeSpan.Zero || settlementBudget > CleanupTimeout)
            throw new ArgumentOutOfRangeException(nameof(settlementTimeout));
        evidence ??= new StartupEvidence();
        Exception? primaryFailure = null;
        var ready = false;
        try
        {
            await evidence.Retain("postgres", startPostgres(startup.Token), startup.Token).WaitAsync(startup.Token);
            await evidence.Retain("redis", startRedis(startup.Token), startup.Token).WaitAsync(startup.Token);
            await evidence.Retain("initialize", initialize(startup.Token), startup.Token).WaitAsync(startup.Token);
            ready = true;
        }
        catch (Exception error)
        {
            primaryFailure = error;
        }
        finally
        {
            if (!ready)
            {
                startup.Cancel();
                if (!evidence.Settled)
                {
                    try { await evidence.Operation!.WaitAsync(settlementBudget); }
                    catch (Exception settlementFailure)
                    {
                        if (!evidence.Settled)
                            throw new AggregateException(primaryFailure!, settlementFailure, new StartupUnsettledException(evidence));
                        // The completed failed operation remains retained alongside primaryFailure.
                    }
                }
                evidence.CleanupAttempted = true;
                try { await DisposePairAsync(disposeRedis, disposePostgres, evidence.Disposal, disposalTimeout); }
                catch (Exception cleanupFailure)
                {
                    throw new AggregateException(primaryFailure!, cleanupFailure);
                }
                evidence.CleanupCallsCompleted = true;
            }
        }

        if (primaryFailure is not null)
            System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(primaryFailure).Throw();
    }

    internal static async Task DisposeOneAsync(string phase, Func<Task> dispose,
        DisposalEvidence evidence, TimeSpan? timeout = null)
    {
        var budget = timeout ?? CleanupTimeout;
        if (budget <= TimeSpan.Zero || budget > CleanupTimeout)
            throw new ArgumentOutOfRangeException(nameof(timeout));
        var operation = evidence.RetainOrReuse(phase, dispose);
        try { await operation.WaitAsync(budget); }
        catch (TimeoutException error) when (!operation.IsCompleted)
        {
            throw new DisposalUnsettledException(phase, operation, evidence, error);
        }
        evidence.ObserveCompletion();
    }

    internal static async Task DisposePairAsync(Func<Task> disposeRedis, Func<Task> disposePostgres,
        DisposalEvidence? evidence = null, TimeSpan? timeout = null)
    {
        evidence ??= new DisposalEvidence();
        var errors = new List<Exception>();
        try { await DisposeOneAsync("redis", disposeRedis, evidence, timeout); }
        catch (Exception error) { errors.Add(error); }
        finally
        {
            try { await DisposeOneAsync("postgres", disposePostgres, evidence, timeout); }
            catch (Exception error) { errors.Add(error); }
        }

        if (errors.Count > 0) throw new AggregateException(errors);
        evidence.ObserveCompletion();
    }
}
