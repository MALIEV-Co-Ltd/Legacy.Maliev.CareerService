using System.Net;
using Docker.DotNet;
using DotNet.Testcontainers.Configurations;
using Microsoft.EntityFrameworkCore;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerRouteFixtureNativeResourceTests
{
    [Fact]
    public async Task ActualAlpineProvidersAndPg18Tmpfs_StartMigrateAndDisappearAfterDisposal()
    {
        var fixture = new CareerRouteFixture();
        using var docker = TestcontainersSettings.OS.DockerEndpointAuthConfig.GetDockerClientConfiguration(Guid.NewGuid()).CreateClient();
        using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(180));
        string? postgresId = null;
        string? redisId = null;
        Exception? observedFailure = null;
        try
        {
            await fixture.InitializeAsync();
            postgresId = fixture.PostgresResource.Id;
            redisId = fixture.RedisResource.Id;
            await AssertContainedAsync(docker, postgresId, 1073741824, 750000000, 128, "/var/lib/postgresql", budget.Token);
            await AssertContainedAsync(docker, redisId, 268435456, 500000000, 64, "/data", budget.Token);
            await using var db = fixture.Context();
            Assert.True(await db.Database.CanConnectAsync(budget.Token));
        }
        catch (Exception error)
        {
            observedFailure = error;
            throw;
        }
        finally
        {
            await DisposeRetainingPrimaryAsync(fixture, observedFailure);
        }

        await AssertAbsentAsync(docker, postgresId!, budget.Token);
        await AssertAbsentAsync(docker, redisId!, budget.Token);
    }

    [Fact]
    public async Task ActualSecondProviderAcquiredThenStartupFails_BothExactIdsAreAbsent()
    {
        var fixture = new CareerRouteFixture();
        using var docker = TestcontainersSettings.OS.DockerEndpointAuthConfig.GetDockerClientConfiguration(Guid.NewGuid()).CreateClient();
        using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(180));
        var primary = new InvalidOperationException("Injected failure after actual second-provider acquisition.");
        string? postgresId = null;
        string? redisId = null;
        Exception? observedFailure = null;
        try
        {
            var actual = await Assert.ThrowsAsync<InvalidOperationException>(() => CareerRouteFixtureLifetime.InitializeAsync(
                cancellation => { fixture.RequireFreshAdmission(); return fixture.PostgresResource.StartAsync(cancellation); },
                async cancellation =>
                {
                    fixture.RequireFreshAdmission();
                    await fixture.RedisResource.StartAsync(cancellation);
                    postgresId = fixture.PostgresResource.Id;
                    redisId = fixture.RedisResource.Id;
                    await AssertContainedAsync(docker, postgresId, 1073741824, 750000000, 128, "/var/lib/postgresql", cancellation);
                    await AssertContainedAsync(docker, redisId, 268435456, 500000000, 64, "/data", cancellation);
                    throw primary;
                }, _ => Task.CompletedTask,
                () => fixture.RedisResource.DisposeAsync().AsTask(),
                () => fixture.PostgresResource.DisposeAsync().AsTask(), TimeSpan.FromSeconds(120), fixture.StartupState));
            Assert.Same(primary, actual);
            await AssertAbsentAsync(docker, postgresId!, budget.Token);
            await AssertAbsentAsync(docker, redisId!, budget.Token);
        }
        catch (Exception error)
        {
            observedFailure = error;
            throw;
        }
        finally
        {
            await DisposeRetainingPrimaryAsync(fixture, observedFailure);
        }
    }

    private static async Task DisposeRetainingPrimaryAsync(CareerRouteFixture fixture, Exception? primary)
    {
        try { await fixture.DisposeAsync(); }
        catch (Exception cleanup) when (primary is not null)
        {
            throw new AggregateException(primary, cleanup);
        }
    }

    private static async Task AssertContainedAsync(IDockerClient docker, string id, long memory, long cpu, long pids, string tmpfs, CancellationToken cancellation)
    {
        Assert.Matches("^[0-9a-f]{64}$", id);
        var actual = await docker.Containers.InspectContainerAsync(id, cancellation);
        Assert.Equal(id, actual.ID);
        Assert.True(actual.State.Running);
        Assert.Equal(memory, actual.HostConfig.Memory);
        Assert.Equal(memory, actual.HostConfig.MemorySwap);
        Assert.Equal(cpu, actual.HostConfig.NanoCPUs);
        Assert.Equal(pids, actual.HostConfig.PidsLimit);
        Assert.Contains(tmpfs, actual.HostConfig.Tmpfs.Keys);
        foreach (var bindings in actual.HostConfig.PortBindings.Values)
            foreach (var binding in bindings) Assert.Equal("127.0.0.1", binding.HostIP);
        Assert.Equal(Environment.GetEnvironmentVariable("MALIEV_TEST_RESOURCE_OWNER"), actual.Config.Labels["maliev.test.owner"]);
        Assert.Matches("^[0-9a-f]{32}$", actual.Config.Labels["maliev.test.fixture"]);
        Assert.Equal("false", actual.Config.Labels["maliev.test.persistent-data"]);
        Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new
        {
            ProviderId = actual.ID, actual.Image, actual.Created,
            Owner = actual.Config.Labels["maliev.test.owner"],
            Fixture = actual.Config.Labels["maliev.test.fixture"],
            actual.HostConfig.Memory, actual.HostConfig.MemorySwap, actual.HostConfig.NanoCPUs, actual.HostConfig.PidsLimit,
            LoopbackOnly = true, Tmpfs = tmpfs
        }));
    }

    private static async Task AssertAbsentAsync(IDockerClient docker, string id, CancellationToken cancellation)
    {
        Assert.Matches("^[0-9a-f]{64}$", id);
        var actual = await Assert.ThrowsAsync<DockerApiException>(() => docker.Containers.InspectContainerAsync(id, cancellation));
        Assert.Equal(HttpStatusCode.NotFound, actual.StatusCode);
        Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new { ProviderId = id, VerifiedAbsent = true }));
    }
}
