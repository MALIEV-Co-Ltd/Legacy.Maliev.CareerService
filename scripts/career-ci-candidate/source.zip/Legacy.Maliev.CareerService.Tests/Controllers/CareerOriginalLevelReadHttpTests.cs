using System.Net;
using System.Text.Json;
using Legacy.Maliev.CareerService.Domain;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerOriginalLevelReadHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Fact]
    public async Task LevelExist_ShouldReturnRequestedLevelId()
    {
        await fixture.ResetAsync();
        int levelId;
        await using (var db = fixture.Context())
        {
            var seed = new JobLevel { Description = "test description", Name = "test name" };
            db.Levels.Add(seed);
            await db.SaveChangesAsync();
            levelId = seed.Id;
        }
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/jobs/levels/{levelId}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal(levelId, json.RootElement.GetProperty("id").GetInt32());
    }

    [Fact]
    public async Task LevelNotExist_ShouldReturnNotFound()
    {
        await fixture.ResetAsync();
        using var client = fixture.Client();
        using var response = await client.GetAsync($"/jobs/levels/{int.MaxValue}");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
