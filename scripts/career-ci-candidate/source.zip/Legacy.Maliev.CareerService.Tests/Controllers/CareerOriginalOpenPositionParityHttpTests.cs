using System.Net;
using System.Text.Json;
using Legacy.Maliev.CareerService.Domain;
using Microsoft.EntityFrameworkCore;

namespace Legacy.Maliev.CareerService.Tests.Controllers;

[Collection("Career open position lifecycle")]
public sealed class CareerOriginalOpenPositionParityHttpTests(CareerRouteFixture fixture)
    : IClassFixture<CareerRouteFixture>
{
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task OriginalFourOfferFilledCohort_PreservesPublicBoolean(bool hasOpenPositions)
    {
        await fixture.ResetAsync();
        var levelId = await fixture.SeedLevelAsync();
        await using (var db = fixture.Context())
        {
            db.Offers.AddRange(Enumerable.Range(0, 4).Select(index => new JobOffer
            {
                LevelId = levelId,
                IsFilled = !(hasOpenPositions && (index == 0 || index == 3))
            }));
            await db.SaveChangesAsync();
        }
        using var client = fixture.Client();
        using var response = await client.GetAsync("/Jobs/job-opening-status");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal(hasOpenPositions, json.RootElement.GetBoolean());
        await using var readback = fixture.Context();
        Assert.Equal(4, await readback.Offers.CountAsync());
        Assert.Equal(hasOpenPositions ? 2 : 0,
            await readback.Offers.CountAsync(offer => offer.IsFilled == false));
        Assert.Equal(hasOpenPositions ? 2 : 4,
            await readback.Offers.CountAsync(offer => offer.IsFilled == true));
    }
}
